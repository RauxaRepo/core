The EventQueue folder is for storing EventQueue messages on disk.
If there is not an EventQueue.config file in this folder then one will be automatically created the first time it is needed.